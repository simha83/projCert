import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.concurrent.TimeUnit;

public class Selenium {

    public static void main(String[] args) {
        try {
            System.out.println("Devops Certificate Project:PHP website automation Testing ");
            System.setProperty("webdriver.chrome.driver", "/user/bin/ChromeDriver");
            WebDriver driver = new ChromeDriver();
            ChromeOptions chromeOptions = new ChromeOptions();
            chromeOptions.addArguments("--headless"); // Runs Chrome in headless mode.
            chromeOptions.addArguments("--screenshot"); //Capture a screenshot of a page
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            //Launch the PHP project
            driver.get("http://192.168.56.101/");
            if(driver.getPageSource().contains("Home")){
                System.out.println("Pass");
            }else{
                System.out.println("fail");
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
